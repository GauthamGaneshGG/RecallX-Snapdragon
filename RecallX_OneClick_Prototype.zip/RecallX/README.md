# RecallX — Private On-Device Work Memory

RecallX is a local-first Snapdragon-oriented prototype that turns your local work/study material into a searchable memory timeline. PDFs become searchable memories, questions can be grounded in those memories, and an optional Qualcomm AI Hub / GenieX path can provide on-device generation.

## One-click Windows launch

**You do not need to type commands.**

1. Extract this ZIP.
2. Open the `RecallX` folder.
3. Double-click **`START_RECALLX.vbs`**.
4. Wait for the browser to open at `http://127.0.0.1:5173`.
5. Keep the small/minimized RecallX service windows running while you use the app.

The first launch automatically creates the Python environment, installs backend packages, installs frontend packages, starts FastAPI + Vite, and opens the browser.

### Requirements
- Windows 10/11
- Python 3.11+ installed and available as `python`
- Node.js LTS installed and available as `npm`

You only need Python and Node.js installed once. You do **not** need to run `pip`, `npm`, `uvicorn`, or `npm run dev` yourself.

## Features
- Local PDF ingestion with page-aware retrieval
- Ask your past / local memory search
- Manual memory timeline
- End-of-session recap questions
- Local-first / cloud-off messaging
- Snapdragon / GenieX runtime status
- Optional Qualcomm AI Hub / NPU generation path

## If the browser does not open
Double-click `run_recallx.bat` instead. It will show setup messages and any missing dependency error.

## Stop RecallX
Close the RecallX Backend and RecallX Frontend windows from the taskbar when you are finished.
