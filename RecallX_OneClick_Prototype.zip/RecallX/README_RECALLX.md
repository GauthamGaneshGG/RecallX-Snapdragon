# RecallX — Private On-Device Work Memory

RecallX is a Snapdragon-oriented prototype that turns local work context into a searchable memory timeline. It extends the original RecallX prototype with:

- local memory timeline for documents, questions, revisions, and manual notes
- grounded retrieval from uploaded PDFs
- optional local Qualcomm AI Hub / GenieX generation
- explicit Snapdragon NPU status panel
- no cloud AI dependency in the prototype
- end-of-session revision generation

## Run on Windows

1. Open the project folder.
2. Double-click `run_recallx.bat`.
3. The browser should open at `http://localhost:5173`.

Manual setup:

```cmd
cd /d "C:\Users\annek\Downloads\RecallX_Snapdragon_Prototype\RecallX\backend"
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python -m uvicorn main:app --host 127.0.0.1 --port 8000
```

In a second terminal:

```cmd
cd /d "C:\Users\annek\Downloads\RecallX_Snapdragon_Prototype\RecallX\frontend"
npm install
npm run dev
```

## Snapdragon / GenieX

The backend checks `http://127.0.0.1:18181/v1/models`. Configure with:

- `PADHAI_GENIEX_URL`
- `PADHAI_GENIEX_MODEL`

The existing RecallX GenieX scripts and Qualcomm deployment notes are retained. Start GenieX separately when your Snapdragon environment is configured.

## Prototype story

> **Your laptop. Now with memory.**

The current prototype intentionally uses explicit events (PDFs, questions, revisions, and manual memories) rather than hidden surveillance. A next iteration can add opt-in Windows screenshot/audio capture with visible recording controls.
