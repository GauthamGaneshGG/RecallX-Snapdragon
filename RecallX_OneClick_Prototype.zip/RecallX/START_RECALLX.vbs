Set shell = CreateObject("WScript.Shell")
batPath = Replace(WScript.ScriptFullName, "START_RECALLX.vbs", "run_recallx.bat")
shell.Run """" & batPath & """", 7, False
Set shell = Nothing
