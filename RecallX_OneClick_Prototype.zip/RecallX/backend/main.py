from __future__ import annotations

import json
import os
import platform
import re
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any

import requests
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pypdf import PdfReader
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
UPLOADS = DATA / "uploads"
STATE = DATA / "index_state.json"
MEMORY_STATE = DATA / "memory_state.json"
UPLOADS.mkdir(parents=True, exist_ok=True)

APP_VERSION = "2.0-snapdragon"
MAX_UPLOAD_BYTES = 50 * 1024 * 1024
FRONTEND_ORIGINS = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
]

GENIEX_BASE = os.getenv("PADHAI_GENIEX_URL", "http://127.0.0.1:18181")
GENIEX_MODEL = os.getenv("PADHAI_GENIEX_MODEL", "ai-hub-models/Qwen3-4B-Instruct-2507")
OLLAMA_BASE = os.getenv("PADHAI_OLLAMA_URL", "http://127.0.0.1:11434")
OLLAMA_MODEL = os.getenv("PADHAI_OLLAMA_MODEL", "qwen2.5:3b")

app = FastAPI(title="RecallX API", version=APP_VERSION)
app.add_middleware(
    CORSMiddleware,
    allow_origins=FRONTEND_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type"],
)

chunks: list[dict[str, Any]] = []
documents: list[dict[str, Any]] = []
memory: list[dict[str, Any]] = []
vectorizer: TfidfVectorizer | None = None
matrix = None


def clean(text: str) -> str:
    text = re.sub(r"\s+", " ", text or "")
    return text.strip()


def split_text(text: str, size: int = 850, overlap: int = 120) -> list[str]:
    """Structure-aware chunking that prefers paragraph/sentence boundaries."""
    text = clean(text)
    if not text:
        return []
    out: list[str] = []
    start = 0
    while start < len(text):
        end = min(len(text), start + size)
        if end < len(text):
            piece = text[start:end]
            boundaries = [piece.rfind(". "), piece.rfind("? "), piece.rfind("! "), piece.rfind("; ")]
            cut = max(boundaries)
            if cut > int(size * 0.55):
                end = start + cut + 1
        piece = text[start:end].strip()
        if len(piece) > 40:
            out.append(piece)
        if end >= len(text):
            break
        start = max(0, end - overlap)
    return out


def extract_pdf(pdf_path: Path, source_name: str) -> tuple[list[dict[str, Any]], int]:
    reader = PdfReader(str(pdf_path))
    page_chunks: list[dict[str, Any]] = []
    global_chunk = 0
    for page_num, page in enumerate(reader.pages, start=1):
        text = page.extract_text() or ""
        for local_idx, piece in enumerate(split_text(text), start=1):
            global_chunk += 1
            page_chunks.append(
                {
                    "text": piece,
                    "source": source_name,
                    "page": page_num,
                    "chunk": local_idx,
                    "global_chunk": global_chunk,
                }
            )
    return page_chunks, len(reader.pages)


def save_state() -> None:
    STATE.write_text(
        json.dumps({"documents": documents, "chunks": chunks}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

def save_memory() -> None:
    MEMORY_STATE.write_text(json.dumps(memory[-500:], ensure_ascii=False, indent=2), encoding="utf-8")

def add_memory(kind: str, title: str, detail: str = "") -> None:
    memory.append({"id": int(time.time() * 1000), "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"), "kind": kind, "title": title, "detail": detail[:1000]})
    del memory[:-500]
    save_memory()


def load_state() -> None:
    global chunks, documents, memory
    if not STATE.exists():
        return
    try:
        data = json.loads(STATE.read_text(encoding="utf-8"))
        documents = data.get("documents", [])
        chunks = data.get("chunks", [])
    except Exception:
        documents, chunks = [], []


def rebuild() -> None:
    global vectorizer, matrix
    corpus = [c["text"] for c in chunks]
    if not corpus:
        vectorizer = matrix = None
        return
    vectorizer = TfidfVectorizer(
        stop_words="english",
        ngram_range=(1, 2),
        max_features=16000,
        sublinear_tf=True,
    )
    matrix = vectorizer.fit_transform(corpus)


def retrieve(query: str, k: int = 5) -> list[dict[str, Any]]:
    if vectorizer is None or matrix is None:
        return []
    q = vectorizer.transform([query])
    scores = cosine_similarity(q, matrix)[0]
    ids = scores.argsort()[::-1]
    results = []
    for idx in ids:
        if scores[idx] <= 0:
            continue
        c = chunks[int(idx)]
        results.append(
            {
                "text": c["text"],
                "source": c["source"],
                "page": c.get("page"),
                "chunk": c.get("chunk"),
                "score": round(float(scores[idx]), 3),
            }
        )
        if len(results) >= k:
            break
    return results


def http_json(url: str, payload: dict[str, Any], timeout: int = 90) -> tuple[bool, dict[str, Any] | None, float]:
    started = time.perf_counter()
    try:
        r = requests.post(url, json=payload, timeout=timeout)
        elapsed = (time.perf_counter() - started) * 1000
        if r.ok:
            try:
                return True, r.json(), elapsed
            except Exception:
                return False, None, elapsed
    except Exception:
        elapsed = (time.perf_counter() - started) * 1000
    return False, None, elapsed


def geniex_available() -> tuple[bool, str | None]:
    try:
        r = requests.get(f"{GENIEX_BASE}/v1/models", timeout=0.5)
        if not r.ok:
            return False, None
        data = r.json().get("data", [])
        ids = [m.get("id") for m in data if m.get("id")]
        preferred = GENIEX_MODEL if GENIEX_MODEL in ids else (ids[0] if ids else None)
        return bool(preferred), preferred
    except Exception:
        return False, None


def ask_geniex(question: str, context: str) -> tuple[str | None, float]:
    ok, selected_model = geniex_available()
    if not ok:
        return None, 0.0
    prompt = (
        "You are RecallX, a private study tutor running locally on a Snapdragon PC. "
        "Answer only from the supplied study context. If the context is insufficient, say so. "
        "Use simple student-friendly language. Do not invent facts.\n\n"
        f"STUDY CONTEXT:\n{context}\n\nQUESTION:\n{question}"
    )
    payload = {
        "model": selected_model or GENIEX_MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.2,
        "max_tokens": 300,
    }
    ok, data, elapsed = http_json(f"{GENIEX_BASE}/v1/chat/completions", payload)
    if not ok or not data:
        return None, elapsed
    try:
        content = data["choices"][0]["message"]["content"].strip()
    except Exception:
        return None, elapsed
    return (content or None), elapsed


def ask_ollama(question: str, context: str) -> tuple[str | None, float]:
    prompt = (
        "You are RecallX, a private study tutor. Answer ONLY from the supplied study context. "
        "If the context does not contain enough information, say so. Use simple student-friendly language. "
        "Do not invent facts.\n\n"
        f"STUDY CONTEXT:\n{context}\n\nQUESTION:\n{question}\n\nANSWER:"
    )
    ok, data, elapsed = http_json(
        f"{OLLAMA_BASE}/api/generate",
        {"model": OLLAMA_MODEL, "prompt": prompt, "stream": False},
        timeout=60,
    )
    if not ok or not data:
        return None, elapsed
    return (data.get("response", "").strip() or None), elapsed


def fallback_answer(question: str, results: list[dict[str, Any]]) -> str:
    if not results:
        return "I couldn't find relevant information in the uploaded study material."
    top = results[0]["text"]
    return (
        "Based on your uploaded notes:\n\n"
        + top[:1400]
        + "\n\nTip: upload more relevant notes if you want a broader answer."
    )


def system_architecture() -> str:
    return platform.machine() or "unknown"


def cpu_name() -> str:
    try:
        if platform.system() == "Windows":
            out = subprocess.check_output(
                ["powershell", "-NoProfile", "-Command", "(Get-CimInstance Win32_Processor).Name"],
                text=True,
                stderr=subprocess.DEVNULL,
                timeout=2,
            )
            return clean(out.splitlines()[0]) if out.strip() else platform.processor() or "unknown"
    except Exception:
        pass
    return platform.processor() or "unknown"


load_state()
rebuild()
if not memory:
    add_memory("system", "RecallX session started", "Local memory is ready. No cloud service is required for the prototype.")


@app.get("/api/health")
def health():
    gx_ok, gx_model = geniex_available()
    return {
        "status": "ok",
        "app_version": APP_VERSION,
        "documents": len(documents),
        "chunks": len(chunks),
        "geniex": gx_ok,
        "geniex_model": gx_model,
    }


@app.get("/api/runtime")
def runtime():
    gx_ok, gx_model = geniex_available()
    target = "Snapdragon-ready" if platform.system() == "Windows" and system_architecture().lower() in {"arm64", "aarch64"} else "Requires Snapdragon Windows ARM64 for NPU mode"
    return {
        "os": platform.system(),
        "architecture": system_architecture(),
        "cpu": cpu_name(),
        "target": target,
        "geniex": {
            "available": gx_ok,
            "model": gx_model,
            "endpoint": GENIEX_BASE,
            "accelerator": "Qualcomm NPU via GenieX/QAIRT" if gx_ok else "not detected",
        },
        "retrieval": "TF-IDF + cosine similarity (local)",
        "cloud_ai": False,
    }


@app.get("/api/documents")
def get_documents():
    return {"documents": documents}

@app.get("/api/memory")
def get_memory():
    return {"memory": list(reversed(memory[-100:]))}

@app.post("/api/memory")
async def create_memory(payload: dict[str, Any]):
    title = clean(str(payload.get("title", "")))
    detail = clean(str(payload.get("detail", "")))
    if not title:
        raise HTTPException(400, "Memory title is required.")
    add_memory("note", title, detail)
    return {"message": "Memory saved locally"}

@app.post("/api/memory/clear")
def clear_memory():
    memory.clear()
    add_memory("system", "Memory cleared", "The local RecallX timeline was reset.")
    return {"message": "Memory cleared"}


@app.post("/api/upload")
async def upload(file: UploadFile = File(...)):
    global chunks, documents
    if not file.filename or not file.filename.lower().endswith(".pdf"):
        raise HTTPException(400, "Only PDF files are supported.")
    raw = await file.read()
    if len(raw) > MAX_UPLOAD_BYTES:
        raise HTTPException(413, f"PDF exceeds the {MAX_UPLOAD_BYTES // (1024 * 1024)} MB local upload limit.")

    safe_name = Path(file.filename).name
    path = UPLOADS / safe_name
    path.write_bytes(raw)

    try:
        new_chunks, pages = extract_pdf(path, safe_name)
    except Exception as e:
        try:
            path.unlink()
        except OSError:
            pass
        raise HTTPException(400, f"Could not read PDF: {e}")

    if not new_chunks:
        raise HTTPException(400, "The PDF contains no extractable text.")

    # Re-uploading the same filename replaces its old index entries.
    chunks = [c for c in chunks if c.get("source") != safe_name] + new_chunks
    documents = [d for d in documents if d.get("name") != safe_name]
    documents.append({"name": safe_name, "pages": pages, "chunks": len(new_chunks)})
    add_memory("document", f"Opened {safe_name}", f"Indexed {pages} pages and {len(new_chunks)} local chunks.")
    rebuild()
    save_state()
    return {"message": "PDF indexed locally", "document": documents[-1]}


@app.post("/api/ask")
async def ask(payload: dict[str, Any]):
    question = clean(str(payload.get("question", "")))
    runtime = clean(str(payload.get("runtime", "auto")).lower()) or "auto"
    if runtime not in {"auto", "snapdragon", "ollama", "extractive"}:
        raise HTTPException(400, "runtime must be auto, snapdragon, ollama, or extractive")
    if not question:
        raise HTTPException(400, "Question is required.")
    if not chunks:
        raise HTTPException(400, "Upload a study PDF first.")

    retrieval_started = time.perf_counter()
    results = retrieve(question, 5)
    retrieval_ms = (time.perf_counter() - retrieval_started) * 1000
    context = "\n\n".join(
        f"[{r['source']} — page {r['page']}] {r['text']}" for r in results
    )

    add_memory("question", question, f"Asked about your local work; retrieved {len(results)} relevant passages.")

    if not context:
        return {"answer": fallback_answer(question, results), "sources": [], "mode": "local-rag-extractive", "retrieval_ms": round(retrieval_ms, 1), "generation_ms": 0, "latency_ms": round(retrieval_ms, 1)}

    if runtime in {"auto", "snapdragon"}:
        answer, generation_ms = ask_geniex(question, context)
        if answer:
            return {"answer": answer, "sources": results, "mode": "snapdragon-ai-hub-npu", "retrieval_ms": round(retrieval_ms, 1), "generation_ms": round(generation_ms, 1), "latency_ms": round(retrieval_ms + generation_ms, 1)}
        if runtime == "snapdragon":
            raise HTTPException(503, "Snapdragon NPU runtime is not available. Start GenieX and pull the configured Qualcomm AI Hub model.")

    if runtime in {"auto", "ollama"}:
        answer, generation_ms = ask_ollama(question, context)
        if answer:
            return {"answer": answer, "sources": results, "mode": "local-rag+ollama", "retrieval_ms": round(retrieval_ms, 1), "generation_ms": round(generation_ms, 1), "latency_ms": round(retrieval_ms + generation_ms, 1)}
        if runtime == "ollama":
            raise HTTPException(503, "Ollama is not available.")

    generation_ms = 0.0
    return {"answer": fallback_answer(question, results), "sources": results, "mode": "local-rag-extractive", "retrieval_ms": round(retrieval_ms, 1), "generation_ms": 0, "latency_ms": round(retrieval_ms, 1)}


@app.post("/api/revision")
async def revision():
    if not chunks:
        raise HTTPException(400, "Upload a study PDF first.")

    sample = chunks[:8]
    context = "\n\n".join(f"[{c['source']} — page {c['page']}] {c['text']}" for c in sample)
    prompt = (
        "Create 5 concise revision questions from the supplied study notes. "
        "Return valid JSON only as an array of objects with keys question and answer_hint. "
        "Do not invent information.\n\nNOTES:\n" + context
    )
    ok, selected_model = geniex_available()
    if ok:
        payload = {
            "model": selected_model or GENIEX_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.2,
            "max_tokens": 500,
        }
        success, data, _elapsed = http_json(f"{GENIEX_BASE}/v1/chat/completions", payload)
        if success and data:
            try:
                raw = data["choices"][0]["message"]["content"].strip()
                match = re.search(r"\[[\s\S]*\]", raw)
                if match:
                    parsed = json.loads(match.group(0))
                    questions = [
                        {"id": i + 1, "question": x.get("question", ""), "answer_hint": x.get("answer_hint", "")}
                        for i, x in enumerate(parsed[:5])
                        if x.get("question")
                    ]
                    if questions:
                        add_memory("revision", "Generated a revision set", "Created 5 practice questions from the local study context.")
                        return {"questions": questions, "mode": "snapdragon-ai-hub-npu"}
            except Exception:
                pass

    # Deterministic fallback: always available and fully local.
    questions = []
    for c in chunks[:6]:
        sentences = re.split(r"(?<=[.!?])\s+", c["text"])
        useful = next((s.strip() for s in sentences if len(s.strip()) > 55), c["text"][:240])
        first = re.split(r"[,.;:]", useful)[0][:100]
        questions.append(
            {
                "id": len(questions) + 1,
                "question": f"Explain the concept described by: \"{first}\"",
                "answer_hint": useful[:220],
            }
        )
        if len(questions) >= 5:
            break
    add_memory("revision", "Generated a revision set", "Created a local fallback revision set from indexed material.")
    return {"questions": questions, "mode": "local-rag-extractive"}


@app.post("/api/clear")
def clear():
    global chunks, documents
    chunks = []
    documents = []
    rebuild()
    save_state()
    try:
        shutil.rmtree(UPLOADS)
    except OSError:
        pass
    UPLOADS.mkdir(parents=True, exist_ok=True)
    add_memory("system", "Study library cleared", "All indexed PDFs and their local retrieval chunks were removed.")
    return {"message": "Index cleared"}
