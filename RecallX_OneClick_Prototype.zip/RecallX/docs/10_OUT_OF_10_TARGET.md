# RecallX — 10/10 target checklist

This is a build target, not a guaranteed judge score. Judges control the final score.

## Technical Implementation

- [x] Working React frontend
- [x] Working FastAPI backend
- [x] PDF extraction on-device
- [x] Page-aware local retrieval
- [x] Qualcomm AI Hub model path
- [x] GenieX local inference path
- [x] NPU-aware runtime status
- [x] CPU/extractive fallback
- [x] Benchmark tooling
- [x] Correct backend launch command

## Application Use Case & Innovation

- [x] Clear education use case
- [x] Student-owned PDFs as knowledge source
- [x] Grounded answers
- [x] Source/page visibility
- [x] Revision generation
- [x] Offline-capable operation after model setup

## Deployment & Accessibility

- [x] Windows local web application
- [x] Simple two-terminal flow
- [x] One-click Snapdragon demo launcher
- [x] Runtime preflight check
- [x] Persistent local index metadata
- [x] No cloud inference dependency

## Presentation & Documentation

- [x] Updated slide deck
- [x] Deployment guide
- [x] Challenge alignment matrix
- [x] Benchmark script
- [x] Preflight script
- [x] Honest evidence boundary

## Participant-controlled conditions that must be confirmed

- [ ] Participant is an eligible India resident aged 18+
- [ ] Participant owns/uses the required Snapdragon-powered HP PC
- [ ] Submission is solely owned by the participant, subject to third-party licenses
- [ ] No confidential information or trade secrets are included
- [ ] Submission history satisfies any pre-existing-proposal condition
- [ ] This is the single submission intended for the challenge
- [ ] Final benchmark numbers come from the actual target PC
- [ ] Any power/efficiency claims are measured and sourced

## Final evidence package for the judges

Before submission, capture one clean demo run showing:

1. Windows ARM64 + Snapdragon processor details.
2. `QUALCOMM NPU ACTIVE` in the RecallX UI.
3. The AI Hub model identifier.
4. A grounded answer with page sources.
5. A generated revision set.
6. Wi-Fi disconnected while the model is already cached.
7. Benchmark output from the same PC.

Only after these are captured can the technical claims be considered fully evidenced.
