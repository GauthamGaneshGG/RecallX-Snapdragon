# RecallX — Challenge alignment matrix

This matrix maps the implementation to the challenge criteria supplied by the participant.

| Criterion | Implemented evidence in RecallX | Demo evidence to capture |
|---|---|---|
| Technical Implementation | FastAPI + React; local PDF extraction; page-aware RAG; Qualcomm AI Hub model path through GenieX; fallback runtimes; runtime diagnostics; benchmark script | Screenshot of NPU-active status, preflight output, benchmark JSON |
| Application Use Case & Innovation | Private study assistant that grounds answers and revision questions in user-selected PDFs | Live PDF Q&A + source snippets + revision generation |
| Deployment & Accessibility | Windows local web app; two-terminal workflow; optional one-click Snapdragon launcher; no cloud AI inference required at runtime | Run locally with Wi-Fi disconnected after model is cached |
| Presentation & Documentation | Updated README, Snapdragon deployment guide, challenge-alignment matrix, benchmark/preflight tools, updated slide deck | Show architecture, model/runtime path, measured results and privacy boundary |

## IP / submission ownership

The code in this repository is the participant's project work. Third-party runtime/model names and dependencies remain subject to their respective licenses and terms. Do not place confidential or trade-secret material into the submitted package.

## Important factual distinction

"Snapdragon target" means the project is designed for Windows ARM64 Snapdragon PCs. "Qualcomm NPU active" is shown only when the local GenieX endpoint is reachable. A final submission should capture that state on the actual Snapdragon-powered HP PC used for the demo.
