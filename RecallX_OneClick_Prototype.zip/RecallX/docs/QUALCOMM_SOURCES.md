# Qualcomm references checked for the Snapdragon implementation

Checked: 2026-09-29

1. Qualcomm Windows on Snapdragon AI: https://www.qualcomm.com/developer/windows-on-snapdragon/windows-on-snapdragon-ai
2. Qualcomm AI Hub model catalog: https://aihub.qualcomm.com/models
3. Qualcomm AI Hub — Qwen3-4B: https://aihub.qualcomm.com/models/qwen3_4b
4. Qualcomm GenieX: https://github.com/qualcomm/GenieX
5. Qualcomm GenieX local server documentation: https://github.com/qualcomm/GenieX/tree/main/docs

Relevant facts used in the project documentation:
- Qualcomm AI Hub lists models optimized/validated for Snapdragon X devices.
- Qualcomm GenieX supports Windows ARM64 on Snapdragon compute devices.
- GenieX exposes a local OpenAI-compatible server endpoint and can run Qualcomm AI Hub bundles through Qualcomm AI Engine Direct on-device.
