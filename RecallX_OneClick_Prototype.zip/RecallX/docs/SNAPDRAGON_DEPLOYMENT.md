# RecallX — Snapdragon AI Lab deployment

## What is implemented

RecallX now has a real Snapdragon-specific inference path instead of only a future roadmap:

```text
PDF
 ↓
pypdf (local)
 ↓
page-aware chunking
 ↓
TF-IDF + cosine retrieval (local CPU)
 ↓
retrieved study context
 ↓
Qualcomm AI Hub model
 ↓
GenieX local server
 ↓
Qualcomm AI Engine / NPU on Snapdragon Windows ARM64
 ↓
answer + cited page snippets
```

The application automatically uses the Snapdragon path when the local GenieX server is reachable. It falls back to Ollama and finally to an extractive local answer so the demo remains usable while setting up the NPU runtime.

## Qualcomm model/runtime

The default model is:

`ai-hub-models/Qwen3-4B-Instruct-2507`

The local app endpoint is:

`http://127.0.0.1:18181/v1`

The FastAPI backend remains on:

`http://127.0.0.1:8000`

## One-time Snapdragon setup

On the Snapdragon-powered HP Windows ARM64 PC, install the current Qualcomm GenieX Windows ARM64 CLI using Qualcomm's current distribution/instructions.

Then run:

```cmd
geniex pull ai-hub-models/Qwen3-4B-Instruct-2507
geniex serve
```

Keep the GenieX terminal open.

## Run RecallX

### Terminal 1 — Backend

```cmd
cd RecallX\backend
.venv\Scripts\activate
python -m uvicorn main:app --host 127.0.0.1 --port 8000
```

### Terminal 2 — Frontend

```cmd
cd RecallX\frontend
npm run dev
```

### Browser

Open:

`http://localhost:5173`

You should see **QUALCOMM NPU ACTIVE** when the GenieX server is reachable.

## Verify before the demo

From the RecallX root:

```cmd
python tools\preflight.py
```

The output should show:

- Windows
- ARM64
- Snapdragon/Qualcomm processor information
- GenieX available
- Qualcomm AI Hub model selected
- Qualcomm NPU accelerator

## Benchmark evidence

Run the NPU benchmark after uploading a sample PDF:

```cmd
python tools\benchmark.py --runtime snapdragon --runs 3
```

For a CPU-only baseline using the same application and same retrieval corpus:

```cmd
python tools\benchmark.py --runtime extractive --runs 3
```

Save the output from the Snapdragon PC as the project evidence. Do not invent or copy latency figures from another device.

## What to show judges

1. Upload `backend/data/dbms_normalization.pdf`.
2. Ask: `Explain 3NF in simple words`.
3. Show the retrieved page snippets.
4. Show `QUALCOMM NPU ACTIVE`.
5. Show the answer mode `snapdragon ai hub npu` and latency.
6. Generate revision questions.
7. Disconnect Wi-Fi and repeat the question.
8. Run `tools\benchmark.py` and show the measured local performance.

## Compliance boundary

This repository implements and documents the Snapdragon/Qualcomm AI Hub path. Actual hardware-specific NPU execution and performance numbers must be demonstrated on the participant's Snapdragon-powered HP PC. The repository cannot honestly claim a measured NPU result until that run has been performed on the target hardware.
