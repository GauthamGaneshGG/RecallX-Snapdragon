import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import { Brain, FileText, Lock, Upload, Send, Sparkles, Trash2, Cpu, Zap, ShieldCheck, WifiOff, Gauge, Clock3, Plus, Search, X } from "lucide-react";
import "./style.css";

const API = "http://127.0.0.1:8000";

function RuntimeBadge({ runtime }) {
  if (!runtime) return <span><Cpu size={14}/> Checking runtime…</span>;
  if (runtime.geniex?.available) return <span className="npu-badge"><Zap size={14}/> Qualcomm NPU active</span>;
  return <span><Cpu size={14}/> Local memory active</span>;
}

function App(){
  const [docs,setDocs]=useState([]), [memory,setMemory]=useState([]), [question,setQuestion]=useState("");
  const [answer,setAnswer]=useState(""), [sources,setSources]=useState([]), [loading,setLoading]=useState(false);
  const [revision,setRevision]=useState([]), [status,setStatus]=useState("Connecting to local RecallX API…"), [runtime,setRuntime]=useState(null);
  const [mode,setMode]=useState(""), [latency,setLatency]=useState(null), [dragging,setDragging]=useState(false), [search,setSearch]=useState("");
  const [noteTitle,setNoteTitle]=useState(""), [noteDetail,setNoteDetail]=useState("");

  async function refresh(){
    try{
      const [docsRes,runtimeRes,memoryRes]=await Promise.all([fetch(API+"/api/documents"),fetch(API+"/api/runtime"),fetch(API+"/api/memory")]);
      if(!docsRes.ok||!runtimeRes.ok||!memoryRes.ok) throw new Error();
      const d=await docsRes.json(), r=await runtimeRes.json(), m=await memoryRes.json();
      setDocs(d.documents||[]); setRuntime(r); setMemory(m.memory||[]);
      setStatus(r.geniex?.available ? "Snapdragon AI memory ready" : "Private local memory ready");
    }catch{setStatus("Start the RecallX backend on port 8000");}
  }
  useEffect(()=>{refresh();const t=setInterval(refresh,4000);return()=>clearInterval(t)},[]);

  async function uploadFile(file){
    if(!file||(!file.type.includes("pdf")&&!file.name.toLowerCase().endsWith(".pdf"))){setStatus("Please choose a PDF file");return}
    setLoading(true);setStatus("Reading and remembering this document locally…");
    const fd=new FormData();fd.append("file",file);
    try{const r=await fetch(API+"/api/upload",{method:"POST",body:fd}),d=await r.json();if(!r.ok)throw new Error(d.detail||"Upload failed");await refresh();setStatus(`Remembered ${file.name}`)}catch(e){setStatus(e.message)}finally{setLoading(false)}
  }
  async function upload(e){await uploadFile(e.target.files?.[0]);e.target.value=""}

  async function ask(){
    if(!question.trim()||loading)return;setLoading(true);setAnswer("");setSources([]);setLatency(null);
    try{const started=performance.now();const r=await fetch(API+"/api/ask",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({question})});const d=await r.json();if(!r.ok)throw new Error(d.detail||"Question failed");setAnswer(d.answer);setSources(d.sources||[]);setMode(d.mode||"");setLatency(d.latency_ms??Math.round(performance.now()-started));setQuestion("");setStatus(d.mode==="snapdragon-ai-hub-npu"?"Answered with Qualcomm AI Hub model on the local NPU":"Answered from local memory") ;refresh()}catch(e){setAnswer(e.message);setStatus("Question failed")}finally{setLoading(false)}
  }
  async function makeRevision(){
    if(loading)return;setLoading(true);setStatus("Reconstructing your study context locally…");
    try{const r=await fetch(API+"/api/revision",{method:"POST"}),d=await r.json();if(!r.ok)throw new Error(d.detail||"Revision generation failed");setRevision(d.questions||[]);setStatus("Revision set added to local memory");refresh()}catch(e){setRevision([{id:1,question:e.message,answer_hint:""}])}finally{setLoading(false)}
  }
  async function addNote(){
    if(!noteTitle.trim())return;await fetch(API+"/api/memory",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({title:noteTitle,detail:noteDetail})});setNoteTitle("");setNoteDetail("");refresh();
  }
  async function clearAll(){await fetch(API+"/api/clear",{method:"POST"});setDocs([]);setAnswer("");setSources([]);setRevision([]);refresh();setStatus("Study library cleared; memory event recorded")}
  async function clearMemory(){await fetch(API+"/api/memory/clear",{method:"POST"});refresh();setStatus("Local timeline cleared")}

  const visibleMemory=memory.filter(x=>(x.title+" "+x.detail).toLowerCase().includes(search.toLowerCase()));
  return <div className="app">
    <header><div className="brand"><div className="logo"><Brain size={25}/></div><div><h1>RecallX</h1><span>Private on-device work memory</span></div></div><div className="badges"><span><Lock size={14}/> Local-first</span><span><WifiOff size={14}/> Cloud off</span><RuntimeBadge runtime={runtime}/></div></header>
    <main>
      <section className="hero"><div><p className="eyebrow">SNAPDRAGON AI LAB • PROTOTYPE</p><h2>Your laptop.<br/><b>Now with memory.</b></h2><p className="sub">RecallX turns your local work into a searchable timeline. Ask what you read, what you changed, or what you were doing earlier — with retrieval and optional AI inference kept on your Snapdragon PC.</p></div><div className="hardware"><div className="dot"></div><strong>{runtime?.geniex?.available?"QUALCOMM NPU ACTIVE":"SNAPDRAGON TARGET"}</strong><span>{runtime?.cpu||"Waiting for local runtime…"}</span><small>{runtime?.geniex?.model||"Start GenieX to activate AI Hub inference"}</small></div></section>

      <section className="memory-banner card"><div><Clock3/><div><b>Local Memory Timeline</b><span>RecallX remembers documents, questions, and your own notes — nothing leaves this prototype.</span></div></div><button onClick={clearMemory}><X size={14}/> Reset timeline</button></section>

      <section className="grid">
        <div className="card upload-card"><div className="card-title"><FileText/><div><h3>Feed your memory</h3><p>PDFs become searchable local memories with page references.</p></div></div><label className={`drop ${dragging?"dragging":""}`} onDragOver={e=>{e.preventDefault();setDragging(true)}} onDragLeave={()=>setDragging(false)} onDrop={e=>{e.preventDefault();setDragging(false);uploadFile(e.dataTransfer.files?.[0])}}><Upload size={30}/><strong>{loading?"Working…":"Remember a PDF"}</strong><span>Click or drag a PDF here</span><input type="file" accept="application/pdf,.pdf" onChange={upload}/></label><div className="docs">{docs.map(d=><div className="doc" key={d.name}><FileText size={17}/><span>{d.name}<small>{d.pages} pages · {d.chunks} memories</small></span></div>)}</div>{docs.length>0&&<button className="danger" onClick={clearAll}><Trash2 size={15}/> Clear local documents</button>}</div>

        <div className="card ask-card"><div className="card-title"><Search/><div><h3>Ask your past</h3><p>Search your local work, then let the on-device model explain it.</p></div></div><div className="askbox"><textarea value={question} onChange={e=>setQuestion(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();ask()}}} placeholder='“What was I working on earlier?” or “Explain the concept I read.”'/><button onClick={ask} disabled={loading}><Send size={18}/></button></div><div className="answer">{answer?<><div className="answer-meta"><h4>Recall</h4>{mode&&<span>{mode.replaceAll("-"," ")}{latency!==null&&<><Gauge size={13}/> {latency} ms</>}</span>}</div><p>{answer}</p></>:<div className="empty">Your answer will appear here, grounded in local memory.</div>}</div>{sources.length>0&&<div className="sources"><h4>Memory evidence</h4>{sources.map((s,i)=><div className="source" key={i}><b>{s.source} · page {s.page} · {Math.round(s.score*100)}%</b><span>{s.text}</span></div>)}</div>}</div>
      </section>

      <section className="card timeline"><div className="section-head"><div className="card-title"><Clock3/><div><h3>What happened?</h3><p>A simple time machine for your work session.</p></div></div><div className="search"><Search size={14}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Filter memory…"/></div></div><div className="timeline-list">{visibleMemory.length?visibleMemory.map(item=><div className="event" key={item.id}><div className="event-dot"></div><div><small>{new Date(item.timestamp).toLocaleString()}</small><b>{item.title}</b><span>{item.detail}</span></div></div>):<div className="empty">No matching memories yet.</div>}</div></section>

      <section className="card note"><div className="card-title"><Plus/><div><h3>Remember something manually</h3><p>Useful for tasks, decisions, or reminders you don't want to lose.</p></div></div><div className="note-grid"><input value={noteTitle} onChange={e=>setNoteTitle(e.target.value)} placeholder="Memory title"/><input value={noteDetail} onChange={e=>setNoteDetail(e.target.value)} placeholder="What should RecallX remember?"/><button className="primary" onClick={addNote}><Plus size={16}/> Remember</button></div></section>

      <section className="card revision"><div className="revision-head"><div className="card-title"><Sparkles/><div><h3>End-of-session recap</h3><p>Generate practice questions from your local study context.</p></div></div><button className="primary" onClick={makeRevision} disabled={loading}><Sparkles size={17}/> Generate</button></div>{revision.length?<div className="questions">{revision.map(q=><div className="q" key={q.id}><b>Q{q.id}</b><span>{q.question}<small>Hint: {q.answer_hint}</small></span></div>)}</div>:<div className="revision-empty">Generate a recap after you have fed RecallX some material.</div>}</section>

      <section className="runtime-card card"><div className="runtime-title"><ShieldCheck size={18}/><div><h3>Snapdragon / on-device status</h3><p>{runtime?.geniex?.available?"A Qualcomm AI Hub model is reachable through local GenieX.":"Local retrieval works now; GenieX can add NPU-powered generation on Snapdragon Windows ARM64."}</p></div></div><div className="runtime-grid"><div><small>OS</small><b>{runtime?.os||"—"}</b></div><div><small>Architecture</small><b>{runtime?.architecture||"—"}</b></div><div><small>AI runtime</small><b>{runtime?.geniex?.available?"GenieX / QAIRT":"Local RAG"}</b></div><div><small>Accelerator</small><b>{runtime?.geniex?.available?"Snapdragon NPU":"Not detected"}</b></div></div></section>
      <div className="status"><span className="live"></span>{status}<span className="right">Browser → Local API → Local memory → optional Snapdragon NPU</span></div>
    </main>
  </div>
}
createRoot(document.getElementById("root")).render(<App/>);
