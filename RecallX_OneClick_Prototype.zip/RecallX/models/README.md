# Model assets

RecallX intentionally does not bundle a multi-gigabyte LLM inside the ZIP.

The Snapdragon demo fetches the selected Qualcomm AI Hub/GenieX model on the target machine, then runs it locally.

Default model:

`ai-hub-models/Qwen3-4B-Instruct-2507`

This keeps the source package small and avoids shipping third-party model weights without the appropriate distribution terms.
