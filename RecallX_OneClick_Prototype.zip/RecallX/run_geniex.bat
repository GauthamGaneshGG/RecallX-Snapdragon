@echo off
setlocal
cd /d "%~dp0"
where geniex >nul 2>nul
if errorlevel 1 (
  echo [RecallX] GenieX CLI was not found.
  echo Install the Qualcomm GenieX Windows ARM64 CLI on the Snapdragon PC first.
  echo See docs\SNAPDRAGON_DEPLOYMENT.md
  pause
  exit /b 1
)
echo [RecallX] Pulling/ensuring the Qualcomm AI Hub model is available...
geniex pull ai-hub-models/Qwen3-4B-Instruct-2507
if errorlevel 1 (
  echo [RecallX] Model pull failed. Check GenieX/login/network and try again.
  pause
  exit /b 1
)
echo [RecallX] Starting local GenieX OpenAI-compatible server on http://127.0.0.1:18181
 echo [RecallX] Keep this window open during the demo.
geniex serve
pause
