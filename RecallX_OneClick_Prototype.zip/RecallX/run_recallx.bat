@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ROOT=%~dp0"
set "PYEXE=%ROOT%backend\.venv\Scripts\python.exe"
set "PY=python"
where py >nul 2>&1 && set "PY=py -3"
where python >nul 2>&1 && set "PY=python"

echo.
echo  ==========================================
echo       RecallX - One Click Launcher
echo  ==========================================
echo.

where python >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Python 3 was not found. Install Python 3.11+ and try again.
  pause
  exit /b 1
)
where npm >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Node.js/npm was not found. Install Node.js LTS and try again.
  pause
  exit /b 1
)

if not exist "%PYEXE%" (
  echo [1/4] Creating RecallX Python environment...
  %PY% -m venv "%ROOT%backend\.venv"
  if errorlevel 1 (
    echo [ERROR] Could not create the Python environment.
    pause
    exit /b 1
  )
)

echo [2/4] Checking backend packages...
"%PYEXE%" -m pip install -r "%ROOT%backend\requirements.txt" > "%TEMP%\recallx_pip.log" 2>&1
if errorlevel 1 (
  echo [ERROR] Backend setup failed. Details: %TEMP%\recallx_pip.log
  type "%TEMP%\recallx_pip.log"
  pause
  exit /b 1
)

if not exist "%ROOT%frontend\node_modules" (
  echo [3/4] Installing frontend packages...
  pushd "%ROOT%frontend"
  call npm install
  if errorlevel 1 (
    popd
    echo [ERROR] Frontend setup failed.
    pause
    exit /b 1
  )
  popd
) else (
  echo [3/4] Frontend packages already installed.
)

echo [4/4] Starting RecallX...
start "RecallX Backend" /min cmd /c "cd /d "%ROOT%backend" && "%PYEXE%" -m uvicorn main:app --host 127.0.0.1 --port 8000"
start "RecallX Frontend" /min cmd /c "cd /d "%ROOT%frontend" && npm run dev -- --host 127.0.0.1"

powershell -NoProfile -ExecutionPolicy Bypass -Command "$ok=$false; for($i=0;$i -lt 30;$i++){ try{ $r=Invoke-WebRequest -UseBasicParsing http://127.0.0.1:5173 -TimeoutSec 1; if($r.StatusCode -ge 200){$ok=$true;break} }catch{}; Start-Sleep -Milliseconds 500 }; if($ok){Start-Process 'http://127.0.0.1:5173'} else {Start-Process 'http://127.0.0.1:5173'}"

echo.
echo RecallX is starting. Your browser will open automatically.
echo You can close this window; the RecallX services will keep running.
timeout /t 3 /nobreak >nul
exit /b 0
