from __future__ import annotations

import argparse
import json
import statistics
import time
from urllib.request import Request, urlopen

API = "http://127.0.0.1:8000"


def post(path: str, payload: dict) -> dict:
    body = json.dumps(payload).encode("utf-8")
    req = Request(API + path, data=body, headers={"Content-Type": "application/json"}, method="POST")
    with urlopen(req, timeout=180) as r:
        return json.loads(r.read().decode("utf-8"))


def benchmark(runtime: str, question: str, runs: int) -> dict:
    samples = []
    last = None
    for _ in range(runs):
        t0 = time.perf_counter()
        last = post("/api/ask", {"question": question, "runtime": runtime})
        wall = (time.perf_counter() - t0) * 1000
        samples.append({
            "wall_ms": round(wall, 1),
            "reported_ms": last.get("latency_ms"),
            "retrieval_ms": last.get("retrieval_ms"),
            "generation_ms": last.get("generation_ms"),
            "mode": last.get("mode"),
        })
    return {
        "runtime_requested": runtime,
        "mode": last.get("mode") if last else None,
        "runs": runs,
        "wall_ms": {
            "mean": round(statistics.mean(x["wall_ms"] for x in samples), 1),
            "min": round(min(x["wall_ms"] for x in samples), 1),
            "max": round(max(x["wall_ms"] for x in samples), 1),
        },
        "samples": samples,
    }


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Benchmark RecallX local vs Snapdragon runtime.")
    ap.add_argument("--question", default="Explain 3NF in simple words")
    ap.add_argument("--runs", type=int, default=3)
    ap.add_argument("--runtime", choices=["extractive", "snapdragon"], default="snapdragon")
    args = ap.parse_args()
    print(json.dumps(benchmark(args.runtime, args.question, args.runs), indent=2))
