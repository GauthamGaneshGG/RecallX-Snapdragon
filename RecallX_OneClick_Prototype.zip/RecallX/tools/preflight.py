from __future__ import annotations

import json
import platform
import sys
import urllib.request


def get(url: str):
    try:
        with urllib.request.urlopen(url, timeout=2) as r:
            return r.status, json.loads(r.read().decode("utf-8"))
    except Exception as e:
        return None, str(e)


print("RecallX Snapdragon preflight")
print("=" * 32)
print(f"Python: {sys.version.split()[0]}")
print(f"OS: {platform.system()} {platform.release()}")
print(f"Architecture: {platform.machine()}")
print(f"Processor: {platform.processor()}")
print()

status, runtime = get("http://127.0.0.1:8000/api/runtime")
if status == 200:
    print("Backend: READY")
    print(json.dumps(runtime, indent=2))
else:
    print("Backend: NOT REACHABLE")
    print(runtime)

status, health = get("http://127.0.0.1:8000/api/health")
if status == 200:
    print("Health: OK")
    print(json.dumps(health, indent=2))
else:
    print("Health: NOT REACHABLE")
    print(health)

print()
print("Compliance check:")
print("- PDF extraction and retrieval: implemented locally")
print("- Page-level source grounding: implemented")
print("- Qualcomm AI Hub model path: implemented through local GenieX API")
print("- Actual NPU execution: must be verified on the Snapdragon PC and reported from that run")
