from __future__ import annotations

from pathlib import Path

from fastapi.testclient import TestClient

from backend.main import app, clear

ROOT = Path(__file__).resolve().parents[1]
PDF = ROOT / "backend" / "data" / "dbms_normalization.pdf"

client = TestClient(app)

r = client.get("/api/health")
assert r.status_code == 200, r.text

with PDF.open("rb") as f:
    r = client.post("/api/upload", files={"file": (PDF.name, f, "application/pdf")})
assert r.status_code == 200, r.text
assert r.json()["document"]["pages"] >= 1

r = client.post("/api/ask", json={"question": "Explain 3NF in simple words", "runtime": "extractive"})
assert r.status_code == 200, r.text
assert r.json()["sources"], r.text
assert "3NF" in r.json()["answer"] or "transitive" in r.json()["answer"].lower()

r = client.post("/api/revision")
assert r.status_code == 200, r.text
assert r.json()["questions"], r.text

r = client.post("/api/clear")
assert r.status_code == 200, r.text

print("RecallX backend smoke test: PASS")
